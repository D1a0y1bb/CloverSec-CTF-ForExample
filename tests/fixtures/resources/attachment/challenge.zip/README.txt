fixture attachment payload
flag{fixture_attachment_ok}
